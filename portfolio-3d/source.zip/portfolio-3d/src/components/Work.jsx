import { useEffect, useRef, useState } from 'react'
import { AnimatePresence } from 'motion/react'
import { gsap, prefersReduced, isCoarse, asset } from '../lib'
import { projects, moreWork } from '../content'
import Cover from './Cover'
import CaseStudy from './CaseStudy'

function Card({ p, i, onOpen }) {
  const el = useRef(null)
  const move = (e) => {
    if (prefersReduced() || isCoarse()) return
    const r = el.current.getBoundingClientRect()
    const px = (e.clientX - r.left) / r.width - 0.5
    const py = (e.clientY - r.top) / r.height - 0.5
    gsap.to(el.current, { rotateY: px * 8, rotateX: -py * 8, duration: 0.6, ease: 'power3.out' })
    el.current.style.setProperty('--gx', `${(px + 0.5) * 100}%`)
    el.current.style.setProperty('--gy', `${(py + 0.5) * 100}%`)
  }
  const leave = () => gsap.to(el.current, { rotateY: 0, rotateX: 0, duration: 0.9, ease: 'elastic.out(1, 0.5)' })
  return (
    <li className={`card card-${i % 3 === 0 ? 'wide' : 'tall'}`} style={{ '--c': p.accent }}>
      <article ref={el} className="card-inner" onPointerMove={move} onPointerLeave={leave}>
        <div className="card-media">
          <Cover project={p} className="card-img" />
        </div>
        <div className="card-body">
          <p className="mono card-meta">
            <span>{p.year}</span>
            <span>{p.kind}</span>
          </p>
          <h3 className="card-title">{p.name}</h3>
          <p className="card-sum">{p.summary}</p>
          <button className="card-open" onClick={(e) => onOpen(p, e.currentTarget)} aria-label={`Open case study: ${p.name}`}>
            <span>Case study</span>
            <span className="arrow" aria-hidden="true">↗</span>
          </button>
        </div>
        <span className="card-glare" aria-hidden="true" />
      </article>
    </li>
  )
}

export default function Work() {
  const root = useRef(null)
  const [open, setOpen] = useState(null)
  const opener = useRef(null)

  useEffect(() => {
    if (prefersReduced()) return
    const ctx = gsap.context(() => {
      gsap.utils.toArray('.card').forEach((c) => {
        gsap.from(c, { y: 80, opacity: 0, duration: 1, ease: 'power3.out', scrollTrigger: { trigger: c, start: 'top 88%' } })
        const img = c.querySelector('.card-img')
        if (img)
          gsap.fromTo(img, { yPercent: -7 }, { yPercent: 7, ease: 'none', scrollTrigger: { trigger: c, start: 'top bottom', end: 'bottom top', scrub: true } })
      })
      gsap.from('.work-head .char', { yPercent: 110, stagger: 0.03, duration: 0.9, ease: 'power4.out', scrollTrigger: { trigger: '.work-head', start: 'top 80%' } })
      gsap.from('.more li', { y: 20, opacity: 0, stagger: 0.06, duration: 0.6, scrollTrigger: { trigger: '.more', start: 'top 85%' } })
    }, root)
    return () => ctx.revert()
  }, [])

  const show = (p, btn) => {
    opener.current = btn
    setOpen(p)
  }
  const close = () => {
    setOpen(null)
    setTimeout(() => opener.current?.focus(), 30)
  }
  const idx = open ? projects.findIndex((x) => x.id === open.id) : -1

  return (
    <section id="work" className="work" ref={root} aria-labelledby="work-title">
      <div className="wrap">
        <div className="work-head">
          <p className="kicker mono">Selected work · {projects.length} case studies</p>
          <h2 id="work-title" className="section-title" aria-label="Selected work">
            {'Selected work'.split('').map((c, i) => (
              <span className="char-mask" key={i} aria-hidden="true">
                <span className="char">{c === ' ' ? ' ' : c}</span>
              </span>
            ))}
          </h2>
        </div>
        <ul className="cards">
          {projects.map((p, i) => (
            <Card key={p.id} p={p} i={i} onOpen={show} />
          ))}
        </ul>

        <div className="more">
          <h3 className="mono">More apps I've shipped</h3>
          <ul>
            {moreWork.map((m) => (
              <li key={m.name}>
                {m.href ? (
                  <a href={m.href} target="_blank" rel="noopener noreferrer">
                    <img src={asset(m.image)} alt="" loading="lazy" width="1280" height="800" />
                    <span className="more-name">{m.name}</span>
                    <span className="more-what">{m.what}</span>
                    <span className="mono more-year">{m.year} ↗</span>
                  </a>
                ) : (
                  <div className="more-static">
                    <img src={asset(m.image)} alt="" loading="lazy" width="1280" height="800" />
                    <span className="more-name">{m.name}</span>
                    <span className="more-what">{m.what}</span>
                    <span className="mono more-year">{m.year}</span>
                  </div>
                )}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <AnimatePresence>
        {open && (
          <CaseStudy
            key={open.id}
            p={open}
            onClose={close}
            onNext={() => setOpen(projects[(idx + 1) % projects.length])}
            next={projects[(idx + 1) % projects.length]}
          />
        )}
      </AnimatePresence>
    </section>
  )
}
