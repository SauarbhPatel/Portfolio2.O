import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { gsap, ScrollTrigger, scene, prefersReduced } from '../lib'
import { services } from '../content'

// Sticky 3D stage: the phone stack from the hero fans out and each face comes forward in turn.
export default function Stage() {
  const root = useRef(null)
  const [idx, setIdx] = useState(0)
  const [reduced] = useState(prefersReduced)

  useEffect(() => {
    if (reduced) return
    const n = services.length
    const st1 = ScrollTrigger.create({
      trigger: root.current,
      start: 'top bottom',
      end: 'top top',
      scrub: true,
      onUpdate: (s) => (scene.morph = s.progress),
    })
    const st2 = ScrollTrigger.create({
      trigger: root.current,
      start: 'top top',
      end: 'bottom bottom',
      scrub: true,
      onUpdate: (s) => {
        scene.stage = s.progress
        setIdx(Math.min(n - 1, Math.round(s.progress * (n - 1))))
      },
    })
    const fill = gsap.fromTo(
      '.stage-progress i',
      { scaleY: 0 },
      { scaleY: 1, ease: 'none', scrollTrigger: { trigger: root.current, start: 'top top', end: 'bottom bottom', scrub: true } }
    )
    return () => {
      st1.kill()
      st2.kill()
      fill.scrollTrigger?.kill()
      fill.kill()
    }
  }, [reduced])

  if (reduced) {
    return (
      <section id="stage" className="stage stage-static" aria-labelledby="stage-title">
        <div className="wrap">
          <p className="kicker mono">What I do</p>
          <h2 id="stage-title" className="section-title">Four things I build.</h2>
          <ol className="stage-list">
            {services.map((s, i) => (
              <li key={s.id} style={{ '--c': s.color }}>
                <span className="mono">0{i + 1}</span>
                <h3>{s.title}</h3>
                <p>{s.caption}</p>
                <ul className="tags">{s.tags.map((t) => <li key={t}>{t}</li>)}</ul>
              </li>
            ))}
          </ol>
        </div>
      </section>
    )
  }

  const s = services[idx]
  return (
    <section
      id="stage"
      className="stage"
      ref={root}
      style={{ height: `${services.length * 90 + 60}vh` }}
      aria-labelledby="stage-title"
    >
      <div className="stage-sticky">
        <div className="stage-caption">
          <p className="kicker mono">What I do</p>
          <h2 id="stage-title" className="sr-only">What I do</h2>
          <div className="stage-count mono" aria-hidden="true">
            <span className="stage-num">0{idx + 1}</span> / 0{services.length}
          </div>
          <div className="stage-live" aria-live="polite">
            <AnimatePresence mode="wait">
              <motion.div
                key={s.id}
                initial={{ y: 40, opacity: 0, filter: 'blur(6px)' }}
                animate={{ y: 0, opacity: 1, filter: 'blur(0px)' }}
                exit={{ y: -30, opacity: 0, filter: 'blur(6px)' }}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
              >
                <h3 className="stage-title" style={{ '--c': s.color }}>
                  {s.title}
                </h3>
                <p className="stage-text">{s.caption}</p>
                <ul className="tags">
                  {s.tags.map((t) => (
                    <li key={t}>{t}</li>
                  ))}
                </ul>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
        <div className="stage-progress" aria-hidden="true">
          <i />
        </div>
        <ol className="stage-dots" aria-hidden="true">
          {services.map((x, i) => (
            <li key={x.id} className={i === idx ? 'on' : ''}>
              {x.title}
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
