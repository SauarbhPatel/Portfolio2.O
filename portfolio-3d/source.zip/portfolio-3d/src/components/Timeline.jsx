import { useEffect, useRef } from 'react'
import { gsap, prefersReduced } from '../lib'
import { experience } from '../content'

export default function Timeline() {
  const root = useRef(null)
  useEffect(() => {
    if (prefersReduced()) return
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.tl-path',
        { strokeDashoffset: 1 },
        { strokeDashoffset: 0, ease: 'none', scrollTrigger: { trigger: '.tl', start: 'top 70%', end: 'bottom 60%', scrub: true } }
      )
      gsap.utils.toArray('.tl-item').forEach((it) => {
        gsap.from(it.querySelector('.tl-card'), {
          y: 40,
          opacity: 0,
          duration: 0.9,
          ease: 'power3.out',
          scrollTrigger: { trigger: it, start: 'top 80%' },
        })
        gsap.to(it, { scrollTrigger: { trigger: it, start: 'top 62%', toggleClass: 'is-on' } })
      })
    }, root)
    return () => ctx.revert()
  }, [])

  return (
    <section id="experience" className="experience" ref={root} aria-labelledby="exp-title">
      <div className="wrap">
        <p className="kicker mono">Experience</p>
        <h2 id="exp-title" className="section-title">
          Five teams, <span className="hand">one habit:</span> shipping.
        </h2>
        <div className="tl">
          <svg className="tl-svg" viewBox="0 0 60 1000" preserveAspectRatio="none" aria-hidden="true">
            <path className="tl-track" d="M30 0 C 52 120, 8 230, 30 340 S 52 560, 30 680 S 8 900, 30 1000" />
            <path className="tl-path" pathLength="1" d="M30 0 C 52 120, 8 230, 30 340 S 52 560, 30 680 S 8 900, 30 1000" />
          </svg>
          <ol className="tl-list">
            {experience.map((e) => (
              <li className="tl-item" key={e.company}>
                <span className="tl-dot" aria-hidden="true" />
                <div className="tl-card">
                  <p className="mono tl-period">{e.period}</p>
                  <h3 className="tl-company">{e.company}</h3>
                  <p className="tl-role">
                    {e.role}
                    {e.place ? ` · ${e.place}` : ''}
                  </p>
                  <p className="tl-outcome">{e.outcome}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  )
}
